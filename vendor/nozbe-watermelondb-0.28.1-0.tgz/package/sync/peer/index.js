"use strict";

exports.__esModule = true;
exports.createPeerSyncClient = createPeerSyncClient;
exports.insecureJsonPeerSyncCodec = void 0;
exports.startPeerSyncServer = startPeerSyncServer;
var _common = require("../../utils/common");
var insecureJsonPeerSyncCodec = exports.insecureJsonPeerSyncCodec = {
  encode: function encode(message) {
    return JSON.stringify(message);
  },
  decode: function decode(encodedMessage) {
    return JSON.parse(encodedMessage);
  }
};
var defaultTimeoutMs = 30000;
var requestCounter = 0;
function isObject(value) {
  return !!value && 'object' === typeof value && !Array.isArray(value);
}
function isPeerSyncRequest(message) {
  return isObject(message) && 'request' === message.type && 'string' === typeof message.id && ['pullChanges', 'pushChanges'].includes(message.method) && isObject(message.params);
}
function isPeerSyncResponse(message) {
  if (!isObject(message) || 'response' !== message.type || 'string' !== typeof message.id) {
    return false;
  }
  if (true === message.ok) {
    return isObject(message.result);
  }
  if (false === message.ok) {
    return isObject(message.error) && 'string' === typeof message.error.code && 'string' === typeof message.error.message;
  }
  return false;
}
function serializeError(error) {
  var anyError = error;
  return {
    code: 'string' === typeof anyError.code ? anyError.code : 'peer_sync_error',
    message: error.message || 'Peer sync request failed'
  };
}
function toError(payload) {
  var error = new Error(payload.message);
  error.code = payload.code;
  return error;
}
function resolveCodec(codec, unsafeAllowUnencryptedMessages) {
  if (codec) {
    return codec;
  }
  (0, _common.invariant)(unsafeAllowUnencryptedMessages, '[Sync] Peer sync requires a secure codec. Pass `codec` (recommended) or explicitly set `unsafeAllowUnencryptedMessages: true` for development only.');
  return insecureJsonPeerSyncCodec;
}
function nextRequestId() {
  requestCounter += 1;
  return "".concat(Date.now(), "-").concat(requestCounter);
}
function createPeerSyncClient({
  transport: transport,
  codec: codec,
  timeoutMs = defaultTimeoutMs,
  authToken: authToken,
  unsafeAllowUnencryptedMessages = false
}) {
  var resolvedCodec = resolveCodec(codec, unsafeAllowUnencryptedMessages);
  var pendingRequests = new Map();
  var closed = false;
  var clearRequest = function clearRequest(requestId) {
    var pending = pendingRequests.get(requestId);
    if (!pending) {
      return null;
    }
    clearTimeout(pending.timeoutId);
    pendingRequests.delete(requestId);
    return pending;
  };
  var rejectAllRequests = function rejectAllRequests(error) {
    pendingRequests.forEach(function (pending) {
      clearTimeout(pending.timeoutId);
      pending.reject(error);
    });
    pendingRequests.clear();
  };
  var unsubscribe = transport.subscribe(function onMessage(encodedMessage) {
    return new Promise(function ($return, $error) {
      var message, responseMessage, pending;
      var $Try_1_Post = function () {
        try {
          if (!isPeerSyncResponse(message)) {
            return $return();
          }
          responseMessage = message;
          pending = clearRequest(responseMessage.id);
          if (!pending) {
            return $return();
          }
          if (responseMessage.ok) {
            pending.resolve(responseMessage.result);
          } else {
            pending.reject(toError(responseMessage.error));
          }
          return $return();
        } catch ($boundEx) {
          return $error($boundEx);
        }
      };
      var $Try_1_Catch = function (decodeError) {
        try {
          rejectAllRequests(new Error('[Sync] Failed to decode peer sync response'));
          return $return();
        } catch ($boundEx) {
          return $error($boundEx);
        }
      };
      try {
        return Promise.resolve(resolvedCodec.decode(encodedMessage)).then(function ($await_10) {
          try {
            message = $await_10;
            return $Try_1_Post();
          } catch ($boundEx) {
            return $Try_1_Catch($boundEx);
          }
        }, $Try_1_Catch);
      } catch (decodeError) {
        $Try_1_Catch(decodeError)
      }
    });
  });
  var sendRequest = function sendRequest(method, params) {
    return new Promise(function ($return, $error) {
      var requestId, request, responsePromise, encodedRequest, pending, _pending;
      (0, _common.invariant)(!closed, '[Sync] Peer sync client has been closed');
      requestId = nextRequestId();
      request = {
        type: 'request',
        id: requestId,
        method: method,
        params: params
      };
      if (authToken) {
        request.authToken = authToken;
      }
      responsePromise = new Promise(function (resolve, reject) {
        var timeoutId = setTimeout(function () {
          pendingRequests.delete(requestId);
          reject(new Error("[Sync] Peer sync request timed out after ".concat(timeoutMs, "ms (").concat(method, ")")));
        }, timeoutMs);
        pendingRequests.set(requestId, {
          resolve: resolve,
          reject: reject,
          timeoutId: timeoutId
        });
      });
      var $Try_2_Post = function () {
        try {
          var $Try_3_Post = function () {
            try {
              return $return(responsePromise);
            } catch ($boundEx) {
              return $error($boundEx);
            }
          };
          var $Try_3_Catch = function (sendError) {
            try {
              _pending = clearRequest(requestId);
              _pending && _pending.reject(sendError);
              return $Try_3_Post();
            } catch ($boundEx) {
              return $error($boundEx);
            }
          };
          try {
            return Promise.resolve(transport.send(encodedRequest)).then(function ($await_11) {
              try {
                return $Try_3_Post();
              } catch ($boundEx) {
                return $Try_3_Catch($boundEx);
              }
            }, $Try_3_Catch);
          } catch (sendError) {
            $Try_3_Catch(sendError)
          }
        } catch ($boundEx) {
          return $error($boundEx);
        }
      };
      var $Try_2_Catch = function (encodeError) {
        try {
          pending = clearRequest(requestId);
          pending && pending.reject(new Error('[Sync] Failed to encode peer sync request'));
          throw encodeError;
        } catch ($boundEx) {
          return $error($boundEx);
        }
      };
      try {
        return Promise.resolve(resolvedCodec.encode(request)).then(function ($await_12) {
          try {
            encodedRequest = $await_12;
            return $Try_2_Post();
          } catch ($boundEx) {
            return $Try_2_Catch($boundEx);
          }
        }, $Try_2_Catch);
      } catch (encodeError) {
        $Try_2_Catch(encodeError)
      }
    });
  };
  return {
    pullChanges: function pullChanges(args) {
      return sendRequest('pullChanges', args);
    },
    pushChanges: function pushChanges(args) {
      return sendRequest('pushChanges', args);
    },
    close: function close() {
      if (closed) {
        return;
      }
      closed = true;
      if ('function' === typeof unsubscribe) {
        unsubscribe();
      }
      rejectAllRequests(new Error('[Sync] Peer sync client was closed'));
    }
  };
}
function startPeerSyncServer({
  transport: transport,
  pullChanges: pullChanges,
  pushChanges: pushChanges,
  codec: codec,
  authorize: authorize,
  onError: onError,
  unsafeAllowUnencryptedMessages = false
}) {
  var resolvedCodec = resolveCodec(codec, unsafeAllowUnencryptedMessages);
  var pushHandler = pushChanges || function (_args) {
    return new Promise(function ($return, $error) {
      return $return({});
    });
  };
  var listener = function listener(encodedMessage) {
    return new Promise(function ($return, $error) {
      var message, requestMessage, response, result, encodedResponse;
      var $Try_4_Post = function () {
        try {
          if (!isPeerSyncRequest(message)) {
            return $return();
          }
          requestMessage = message;
          var $Try_5_Post = function () {
            try {
              var $Try_6_Post = function () {
                try {
                  return $return();
                } catch ($boundEx) {
                  return $error($boundEx);
                }
              };
              var $Try_6_Catch = function (sendError) {
                try {
                  onError && onError(sendError);
                  return $Try_6_Post();
                } catch ($boundEx) {
                  return $error($boundEx);
                }
              };
              try {
                return Promise.resolve(resolvedCodec.encode(response)).then(function ($await_13) {
                  try {
                    encodedResponse = $await_13;
                    return Promise.resolve(transport.send(encodedResponse)).then(function ($await_14) {
                      try {
                        return $Try_6_Post();
                      } catch ($boundEx) {
                        return $Try_6_Catch($boundEx);
                      }
                    }, $Try_6_Catch);
                  } catch ($boundEx) {
                    return $Try_6_Catch($boundEx);
                  }
                }, $Try_6_Catch);
              } catch (sendError) {
                $Try_6_Catch(sendError)
              }
            } catch ($boundEx) {
              return $error($boundEx);
            }
          };
          var $Try_5_Catch = function (requestError) {
            try {
              response = {
                type: 'response',
                id: requestMessage.id,
                ok: false,
                error: serializeError(requestError)
              };
              onError && onError(requestError);
              return $Try_5_Post();
            } catch ($boundEx) {
              return $error($boundEx);
            }
          };
          try {
            if (authorize) {
              return Promise.resolve(authorize({
                method: requestMessage.method,
                authToken: requestMessage.authToken
              })).then(function ($await_15) {
                try {
                  return $If_8.call(this);
                } catch ($boundEx) {
                  return $Try_5_Catch($boundEx);
                }
              }.bind(this), $Try_5_Catch);
            }
            function $If_8() {
              return Promise.resolve(new Promise(function ($return, $error) {
                if ('pullChanges' === requestMessage.method) {
                  return Promise.resolve(pullChanges(requestMessage.params)).then($return, $error);
                }
                return Promise.resolve(pushHandler(requestMessage.params)).then($return, $error);
              })).then(function ($await_18) {
                try {
                  result = $await_18;
                  response = {
                    type: 'response',
                    id: requestMessage.id,
                    ok: true,
                    result: result || {}
                  };
                  return $Try_5_Post();
                } catch ($boundEx) {
                  return $Try_5_Catch($boundEx);
                }
              }, $Try_5_Catch);
            }
            return $If_8.call(this);
          } catch (requestError) {
            $Try_5_Catch(requestError)
          }
        } catch ($boundEx) {
          return $error($boundEx);
        }
      };
      var $Try_4_Catch = function (decodeError) {
        try {
          onError && onError(new Error('[Sync] Failed to decode peer sync request'));
          return $return();
        } catch ($boundEx) {
          return $error($boundEx);
        }
      };
      try {
        return Promise.resolve(resolvedCodec.decode(encodedMessage)).then(function ($await_19) {
          try {
            message = $await_19;
            return $Try_4_Post();
          } catch ($boundEx) {
            return $Try_4_Catch($boundEx);
          }
        }, $Try_4_Catch);
      } catch (decodeError) {
        $Try_4_Catch(decodeError)
      }
    });
  };
  var unsubscribe = transport.subscribe(listener);
  return {
    stop: function stop() {
      if ('function' === typeof unsubscribe) {
        unsubscribe();
      }
    }
  };
}