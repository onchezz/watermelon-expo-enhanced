"use strict";

exports.__esModule = true;
exports.ReactiveQuery = ReactiveQuery;
exports.useReactiveQuery = useReactiveQuery;
exports.useReactiveSingle = useReactiveSingle;
var React = _interopRequireWildcard(require("react"));
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
var initialState = function () {
  return {
    data: null,
    error: null,
    isLoading: true
  };
};
function useReactiveQuery(buildQuery, deps = []) {
  var [state, setState] = React.useState(initialState());

  // deps are explicitly provided by the caller to control query resubscription.
  /* eslint-disable react-hooks/exhaustive-deps */
  React.useEffect(function () {
    var isActive = true;
    var unsubscribe = function () {};
    setState(initialState());
    try {
      var query = buildQuery();
      var subscription = query.observe().subscribe(function (response) {
        if (!isActive) {
          return;
        }
        setState({
          data: response.data,
          error: response.error,
          isLoading: false
        });
      }, function (error) {
        if (!isActive) {
          return;
        }
        setState({
          data: null,
          error: error,
          isLoading: false
        });
      });
      unsubscribe = function () {
        subscription.unsubscribe();
      };
    } catch (error) {
      setState({
        data: null,
        error: error,
        isLoading: false
      });
    }
    return function () {
      isActive = false;
      unsubscribe();
    };
  }, deps);
  /* eslint-enable react-hooks/exhaustive-deps */

  return state;
}
function useReactiveSingle(buildQuery, deps = []) {
  var rowsState = useReactiveQuery(buildQuery, deps);
  if (rowsState.error || rowsState.isLoading) {
    return {
      data: null,
      error: rowsState.error,
      isLoading: rowsState.isLoading
    };
  }
  var rows = rowsState.data || [];
  if (1 < rows.length) {
    return {
      data: null,
      error: new Error("[Reactive] useReactiveSingle expected <= 1 row, but got ".concat(rows.length)),
      isLoading: false
    };
  }
  return {
    data: rows[0] || null,
    error: null,
    isLoading: false
  };
}
function ReactiveQuery({
  buildQuery: buildQuery,
  deps = [],
  children: children
}) {
  var state = useReactiveQuery(buildQuery, deps);
  return children(state);
}