"use strict";

exports.__esModule = true;
exports.createReactiveClient = createReactiveClient;
var _common = require("../utils/common");
var _rx = require("../utils/rx");
var _Schema = require("../Schema");
var Q = _interopRequireWildcard(require("../QueryDescription"));
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
var RESERVED_RAW_COLUMNS = ['_status', '_changed'];
var IMMUTABLE_COLUMNS = ['id', '_status', '_changed'];
var successResponse = function (data) {
  return {
    data: data,
    error: null
  };
};
var errorResponse = function (error) {
  return {
    data: null,
    error: error
  };
};
var isObject = function (value) {
  return !!value && 'object' === typeof value && !Array.isArray(value);
};
var parseSelectColumns = function (columns) {
  if (!columns || '*' === columns) {
    return null;
  }
  var parsed = Array.isArray(columns) ? columns : columns.split(',');
  var normalized = parsed.map(function (column) {
    return column.trim();
  }).filter(Boolean);
  if (!normalized.length || normalized.includes('*')) {
    return null;
  }
  return Array.from(new Set(normalized));
};
var normalizeRows = function (values, action) {
  var rows = Array.isArray(values) ? values : [values];
  (0, _common.invariant)(0 < rows.length, "[Reactive] ".concat(action, " expects at least one row"));
  rows.forEach(function (row, idx) {
    (0, _common.invariant)(isObject(row), "[Reactive] ".concat(action, " expects plain object rows (row ").concat(idx + 1, ")"));
  });
  return rows;
};
var normalizePatch = function (values, action) {
  (0, _common.invariant)(isObject(values), "[Reactive] ".concat(action, " expects a plain object"));
  var keys = Object.keys(values);
  (0, _common.invariant)(0 < keys.length, "[Reactive] ".concat(action, " expects at least one column value"));
  keys.forEach(function (key) {
    (0, _common.invariant)(!IMMUTABLE_COLUMNS.includes(key), "[Reactive] ".concat(action, " cannot modify '").concat(key, "'"));
  });
  return values;
};
var rawToRow = function (raw, selectedColumns) {
  var columns = selectedColumns || Object.keys(raw).filter(function (column) {
    return !RESERVED_RAW_COLUMNS.includes(column);
  });
  return columns.reduce(function (row, column) {
    row[column] = raw[column];
    return row;
  }, {});
};
var recordsToRows = function (records, selectedColumns) {
  return (
    // $FlowFixMe
    records.map(function (record) {
      return rawToRow(record._raw, selectedColumns);
    })
  );
};
var stripImmutableColumns = function (row) {
  return Object.keys(row).reduce(function (next, key) {
    if (!IMMUTABLE_COLUMNS.includes(key)) {
      next[key] = row[key];
    }
    return next;
  }, {});
};
var applyPatchToRecord = function (record, values) {
  Object.keys(values).forEach(function (key) {
    // $FlowFixMe
    record._setRaw((0, _Schema.columnName)(key), values[key]);
  });
};
var findByIdOrNull = function (collection, id) {
  return new Promise(function ($return, $error) {
    var $Try_1_Catch = function () {
      try {
        return $return(null);
      } catch ($boundEx) {
        return $error($boundEx);
      }
    };
    try {
      return Promise.resolve(collection.find(id)).then($return, $Try_1_Catch);
    } catch (_error) {
      $Try_1_Catch(_error)
    }
  });
};
var ReactiveTableQuery = /*#__PURE__*/function () {
  function ReactiveTableQuery(collection, clauses = [], selectedColumns = null) {
    this._collection = collection;
    this._clauses = clauses;
    this._selectedColumns = selectedColumns;
  }
  var _proto = ReactiveTableQuery.prototype;
  _proto._clone = function ({
    clauses: clauses,
    selectedColumns: selectedColumns
  } = {}) {
    return new ReactiveTableQuery(this._collection, clauses || this._clauses, selectedColumns === undefined ? this._selectedColumns : selectedColumns);
  };
  _proto._appendClause = function (clause) {
    return this._clone({
      clauses: this._clauses.concat([clause])
    });
  };
  _proto._query = function () {
    return this._collection.query(this._clauses);
  };
  _proto._rowsFromRecords = function (records) {
    return recordsToRows(records, this._selectedColumns);
  };
  _proto.select = function (columns) {
    return this._clone({
      selectedColumns: parseSelectColumns(columns)
    });
  };
  _proto.eq = function (column, value) {
    return this._appendClause(Q.where((0, _Schema.columnName)(column), value));
  };
  _proto.neq = function (column, value) {
    return this._appendClause(Q.where((0, _Schema.columnName)(column), Q.notEq(value)));
  };
  _proto.gt = function (column, value) {
    return this._appendClause(Q.where((0, _Schema.columnName)(column), Q.gt(value)));
  };
  _proto.gte = function (column, value) {
    return this._appendClause(Q.where((0, _Schema.columnName)(column), Q.gte(value)));
  };
  _proto.lt = function (column, value) {
    return this._appendClause(Q.where((0, _Schema.columnName)(column), Q.lt(value)));
  };
  _proto.lte = function (column, value) {
    return this._appendClause(Q.where((0, _Schema.columnName)(column), Q.lte(value)));
  };
  _proto.in = function (column, values) {
    return this._appendClause(Q.where((0, _Schema.columnName)(column), Q.oneOf(values)));
  };
  _proto.match = function (values) {
    (0, _common.invariant)(isObject(values), "[Reactive] match() expects a plain object");
    return Object.keys(values).reduce(function (query, column) {
      return query.eq(column, values[column]);
    }, this);
  };
  _proto.order = function (column, options = {}) {
    var sortOrder = false === options.ascending ? Q.desc : Q.asc;
    return this._appendClause(Q.sortBy((0, _Schema.columnName)(column), sortOrder));
  };
  _proto.limit = function (count) {
    return this._appendClause(Q.take(count));
  };
  _proto.range = function (from, to) {
    (0, _common.invariant)(0 <= from && to >= from, "[Reactive] range() expects 0 <= from <= to");
    return this._clone({
      clauses: this._clauses.concat([Q.skip(from), Q.take(to - from + 1)])
    });
  };
  _proto.fetch = function () {
    return new Promise(function ($return, $error) {
      var records;
      var $Try_2_Catch = function (error) {
        try {
          return $return(errorResponse(error));
        } catch ($boundEx) {
          return $error($boundEx);
        }
      };
      try {
        return Promise.resolve(this._query().fetch()).then(function ($await_15) {
          try {
            records = $await_15;
            return $return(successResponse(this._rowsFromRecords(records)));
          } catch ($boundEx) {
            return $Try_2_Catch($boundEx);
          }
        }.bind(this), $Try_2_Catch);
      } catch (error) {
        $Try_2_Catch(error)
      }
    }.bind(this));
  };
  _proto.single = function () {
    return new Promise(function ($return, $error) {
      var response, rows;
      return Promise.resolve(this.fetch()).then(function ($await_16) {
        try {
          response = $await_16;
          if (response.error) {
            return $return(errorResponse(response.error));
          }
          rows = response.data || [];
          if (1 !== rows.length) {
            return $return(errorResponse(new Error("[Reactive] Expected a single row, but received ".concat(rows.length, " rows"))));
          }
          return $return(successResponse(rows[0]));
        } catch ($boundEx) {
          return $error($boundEx);
        }
      }, $error);
    }.bind(this));
  };
  _proto.maybeSingle = function () {
    return new Promise(function ($return, $error) {
      var response, rows;
      return Promise.resolve(this.fetch()).then(function ($await_17) {
        try {
          response = $await_17;
          if (response.error) {
            return $return(errorResponse(response.error));
          }
          rows = response.data || [];
          if (1 < rows.length) {
            return $return(errorResponse(new Error("[Reactive] Expected zero or one row, but received ".concat(rows.length, " rows"))));
          }
          return $return(successResponse(rows[0] || null));
        } catch ($boundEx) {
          return $error($boundEx);
        }
      }, $error);
    }.bind(this));
  };
  _proto.observe = function () {
    var _this = this;
    return this._query().observe().pipe((0, _rx.map)(function (records) {
      return successResponse(_this._rowsFromRecords(records));
    }));
  };
  _proto.subscribe = function (subscriber) {
    var _this2 = this;
    return this._query().experimentalSubscribe(function (records) {
      subscriber(successResponse(_this2._rowsFromRecords(records)));
    });
  };
  _proto.insert = function (values) {
    return new Promise(function ($return, $error) {
      var _this3, rows, insertedRecords;
      _this3 = this;
      rows = normalizeRows(values, 'insert()');
      var $Try_3_Catch = function (error) {
        try {
          return $return(errorResponse(error));
        } catch ($boundEx) {
          return $error($boundEx);
        }
      };
      try {
        insertedRecords = [];
        return Promise.resolve(this._collection.database.write(function () {
          return new Promise(function ($return, $error) {
            insertedRecords = rows.map(function (row) {
              return _this3._collection.prepareCreateFromDirtyRaw(row);
            });
            return Promise.resolve(_this3._collection.database.batch(insertedRecords)).then(function () {
              try {
                return $return();
              } catch ($boundEx) {
                return $error($boundEx);
              }
            }, $error);
          });
        })).then(function () {
          try {
            return $return(successResponse(this._rowsFromRecords(insertedRecords)));
          } catch ($boundEx) {
            return $Try_3_Catch($boundEx);
          }
        }.bind(this), $Try_3_Catch);
      } catch (error) {
        $Try_3_Catch(error)
      }
    }.bind(this));
  };
  _proto.update = function (values) {
    return new Promise(function ($return, $error) {
      var _this4, patch, updatedRecords;
      _this4 = this;
      patch = normalizePatch(values, 'update()');
      var $Try_4_Catch = function (error) {
        try {
          return $return(errorResponse(error));
        } catch ($boundEx) {
          return $error($boundEx);
        }
      };
      try {
        updatedRecords = [];
        return Promise.resolve(this._collection.database.write(function () {
          return new Promise(function ($return, $error) {
            var prepared;
            return Promise.resolve(_this4._query().fetch()).then(function ($await_20) {
              try {
                updatedRecords = $await_20;
                prepared = updatedRecords.map(function (record) {
                  return record.prepareUpdate(function (editingRecord) {
                    applyPatchToRecord(editingRecord, patch);
                  });
                });
                if (prepared.length) {
                  return Promise.resolve(_this4._collection.database.batch(prepared)).then(function () {
                    try {
                      return function () {
                        return $return();
                      }.call(this);
                    } catch ($boundEx) {
                      return $error($boundEx);
                    }
                  }.bind(this), $error);
                }
                return function () {
                  return $return();
                }.call(this);
              } catch ($boundEx) {
                return $error($boundEx);
              }
            }.bind(this), $error);
          });
        })).then(function () {
          try {
            return $return(successResponse(this._rowsFromRecords(updatedRecords)));
          } catch ($boundEx) {
            return $Try_4_Catch($boundEx);
          }
        }.bind(this), $Try_4_Catch);
      } catch (error) {
        $Try_4_Catch(error)
      }
    }.bind(this));
  };
  _proto.delete = function () {
    return new Promise(function ($return, $error) {
      var _this5, deletedRows;
      _this5 = this;
      var $Try_5_Catch = function (error) {
        try {
          return $return(errorResponse(error));
        } catch ($boundEx) {
          return $error($boundEx);
        }
      };
      try {
        deletedRows = [];
        return Promise.resolve(this._collection.database.write(function () {
          return new Promise(function ($return, $error) {
            var records, prepared;
            return Promise.resolve(_this5._query().fetch()).then(function ($await_23) {
              try {
                records = $await_23;
                deletedRows = _this5._rowsFromRecords(records);
                prepared = records.map(function (record) {
                  return record.prepareMarkAsDeleted();
                });
                if (prepared.length) {
                  return Promise.resolve(_this5._collection.database.batch(prepared)).then(function () {
                    try {
                      return function () {
                        return $return();
                      }.call(this);
                    } catch ($boundEx) {
                      return $error($boundEx);
                    }
                  }.bind(this), $error);
                }
                return function () {
                  return $return();
                }.call(this);
              } catch ($boundEx) {
                return $error($boundEx);
              }
            }.bind(this), $error);
          });
        })).then(function () {
          try {
            return $return(successResponse(deletedRows));
          } catch ($boundEx) {
            return $Try_5_Catch($boundEx);
          }
        }, $Try_5_Catch);
      } catch (error) {
        $Try_5_Catch(error)
      }
    }.bind(this));
  };
  _proto.upsert = function (values, options = {}) {
    return new Promise(function ($return, $error) {
      var _this6, rows, onConflict, normalizedConflict, touchedRecords;
      _this6 = this;
      rows = normalizeRows(values, 'upsert()');
      onConflict = options.onConflict;
      if (onConflict) {
        normalizedConflict = Array.isArray(onConflict) ? onConflict : [onConflict];
        (0, _common.invariant)(1 === normalizedConflict.length && 'id' === normalizedConflict[0], "[Reactive] upsert() currently supports onConflict: 'id' only");
      }
      var $Try_6_Catch = function (error) {
        try {
          return $return(errorResponse(error));
        } catch ($boundEx) {
          return $error($boundEx);
        }
      };
      try {
        touchedRecords = [];
        return Promise.resolve(this._collection.database.write(function () {
          return new Promise(function ($return, $error) {
            var preparedRecords, _loop;
            preparedRecords = [];
            _loop = function _loop() {
              return new Promise(function ($return, $error) {
                var recordId, existingRecord, patch, createdRecord;
                recordId = row.id;
                if ('string' === typeof recordId) {
                  return Promise.resolve(findByIdOrNull(_this6._collection, recordId)).then(function ($await_26) {
                    try {
                      existingRecord = $await_26;
                      if (existingRecord) {
                        patch = stripImmutableColumns(row);
                        if (Object.keys(patch).length) {
                          existingRecord.prepareUpdate(function (editingRecord) {
                            applyPatchToRecord(editingRecord, patch);
                          });
                          preparedRecords.push(existingRecord);
                        }
                        touchedRecords.push(existingRecord);
                        // eslint-disable-next-line no-continue
                        return $return(1); // continue
                      }
                      return $If_9.call(this);
                    } catch ($boundEx) {
                      return $error($boundEx);
                    }
                  }.bind(this), $error);
                }
                function $If_9() {
                  createdRecord = _this6._collection.prepareCreateFromDirtyRaw(row);
                  preparedRecords.push(createdRecord);
                  touchedRecords.push(createdRecord);
                  return $return();
                }
                return $If_9.call(this);
              });
            };
            var row,
              $iterator_row_10 = [rows[Symbol.iterator]()];
            var $Loop_11_trampoline;
            function $Loop_11() {
              if (!($iterator_row_10[1] = $iterator_row_10[0].next()).done && ((row = $iterator_row_10[1].value) || true)) {
                return Promise.resolve(_loop()).then(function ($await_27) {
                  try {
                    if ($await_27) return $Loop_11;
                    return $Loop_11;
                  } catch ($boundEx) {
                    return $error($boundEx);
                  }
                }, $error);
              } else return [1];
            }
            return ($Loop_11_trampoline = function (q) {
              while (q) {
                if (q.then) return void q.then($Loop_11_trampoline, $error);
                try {
                  if (q.pop) {
                    if (q.length) return q.pop() ? $Loop_11_exit.call(this) : q;else q = $Loop_11;
                  } else q = q.call(this);
                } catch (_exception) {
                  return $error(_exception);
                }
              }
            }.bind(this))($Loop_11);
            function $Loop_11_exit() {
              if (preparedRecords.length) {
                return Promise.resolve(_this6._collection.database.batch(preparedRecords)).then(function ($await_28) {
                  try {
                    return $If_13.call(this);
                  } catch ($boundEx) {
                    return $error($boundEx);
                  }
                }.bind(this), $error);
              }
              function $If_13() {
                return $return();
              }
              return $If_13.call(this);
            }
          });
        })).then(function ($await_29) {
          try {
            return $return(successResponse(this._rowsFromRecords(touchedRecords)));
          } catch ($boundEx) {
            return $Try_6_Catch($boundEx);
          }
        }.bind(this), $Try_6_Catch);
      } catch (error) {
        $Try_6_Catch(error)
      }
    }.bind(this));
  };
  return ReactiveTableQuery;
}();
function createReactiveClient(database) {
  (0, _common.invariant)(database, "[Reactive] Missing database passed to createReactiveClient()");
  return {
    from: function from(tableName) {
      // $FlowFixMe[incompatible-call]
      var collection = database.get(tableName);
      return new ReactiveTableQuery(collection);
    }
  };
}